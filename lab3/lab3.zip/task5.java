public class task5 {
   public static int search(int[] arr){
       int max=0;
       int secmax=0;
       for (int i = 0; i < arr.length; i++) {
           if(arr[i]>max){
               max=arr[i];
           }
       }
       for (int i = 0; i < arr.length; i++) {
           if(arr[i]<max){
               secmax=i;
           }
       }
       return secmax;
   }
    public static void main(String[] args) {
        int[] arr={2,9,6,7,8};
        int secmax=search(arr);
        System.out.println("Second max found at index "+secmax);
    }
}
