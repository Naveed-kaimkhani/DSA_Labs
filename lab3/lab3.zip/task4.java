public class task4 {
    public static float Average(int[] arr,int size){
        float sum=0;
        for (int i = 0; i < arr.length; i++) {
            sum+=arr[i];
        }
        sum=sum/size;
        return sum;
    }
    public static void main(String[] args) {
        int[] arr=new int[]{3,4,5};

        float ave=Average(arr,arr.length);
        System.out.println("Average is "+ave);
    }
}
