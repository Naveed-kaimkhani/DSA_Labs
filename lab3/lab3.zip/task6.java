import java.util.Arrays; 
public class task6 {
    public static void sort(int[][] arr){
        for (int i = 0; i < arr.length; i++) {
            // for (int j = 0; j < arr[i].length; j++) {
            //     if(arr[i][i]>arr[i][j]){
            //         int temp=arr[i][i];
            //         arr[i][i]=arr[i][j];
            //         arr[i][j]=temp;
            //     }
            // }
            Arrays.sort(arr[i]);
        }
        for (int i = 0; i < arr.length; i++) {
            for (int j = 0; j < arr[i].length; j++) {
                System.out.print(arr[i][j]+" ");
            }
            System.out.println();
        }
    }
            public static void main(String[] args) {
                int a[][]={
                    {1,3,2},
                    {4,6,5},
                    {3,1,3}};
                
                
                    sort(a);
    }
}
